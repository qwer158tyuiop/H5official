
//点击跳转网页
function redirectTo(url){
    window.location.href=url;
}
// 消息弹窗
function showAlert(msg){
    alert(msg)
}